#!/usr/bin/env python3
"""Verify distributed hashes, fixed input identities and result completeness; no training."""
from pathlib import Path
import csv,hashlib,json,math
from audit_region_data import audit_region_files
ROOT=Path(__file__).resolve().parents[1]
def main():
 manifest=json.loads((ROOT/'release_manifest.json').read_text())
 actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='release_manifest.json'}
 assert actual==set(manifest),'Missing or unlisted release files'
 for name,m in manifest.items():
  b=(ROOT/name).read_bytes();assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256'],name
 report=audit_region_files(ROOT/'data/train_regions.jsonl',ROOT/'data/val_regions.jsonl');assert report['passed']
 base=[]
 for name in ['train_regions.jsonl','val_regions.jsonl']:
  base.append({(r['dataset'],r['row_idx'],r['canonical_smiles'],float(r['y'])) for r in map(json.loads,(ROOT/'data'/name).open())})
 coverage=json.loads((ROOT/'supplementary/results/threshold5_coverage.json').read_text())
 for mode in coverage:
  d=ROOT/'data' if mode=='nominal' else ROOT/'supplementary/threshold_data'/mode
  for i,(split,name) in enumerate([('train','train_regions.jsonl'),('val','val_regions.jsonl')]):
   f=d/name;rows=list(map(json.loads,f.open()));assert {(r['dataset'],r['row_idx'],r['canonical_smiles'],float(r['y'])) for r in rows}==base[i]
   assert hashlib.sha256(f.read_bytes()).hexdigest()==coverage[mode][split]['sha256']
   assert sum(bool(r['cliff_existence_label']) for r in rows)==coverage[mode][split]['positives']
 for mode in ['full','gine3_only','random_region']:
  for s in range(5):
   rows=list(csv.DictReader((ROOT/'results'/f'{mode}_seed_{s}.csv').open()));assert len(rows)==30 and len({r['dataset'] for r in rows})==30
   assert all(math.isfinite(float(r[k])) for r in rows for k in ['test_rmse','test_cliff_rmse'])
 for mode in ['scratch_property','scratch_full','skip_unsupported']:
  for s in range(5):
   rows=list(csv.DictReader((ROOT/'supplementary/results'/f'{mode}_seed_{s}.csv').open()));assert len(rows)==30
   assert all(math.isfinite(float(r[k])) for r in rows for k in ['test_rmse','test_cliff_rmse'])
 scores=json.loads((ROOT/'supplementary/results/threshold5_seed_summaries.json').read_text());assert len(scores)==7
 for mode,seeds in scores.items():
  assert set(seeds)==set(map(str,range(5)))
  for rows in seeds.values():
   assert len(rows)==30 and all(r['validation_only']=='True' and int(r['n_official_test'])==0 and math.isfinite(float(r['best_val_rmse'])) for r in rows)
 loc=json.loads((ROOT/'supplementary/results/localization_aggregate.json').read_text());assert loc['smoke_only'] is False
 for mode in ['scratch_full','skip_unsupported']:assert set(loc['seed_macros'][mode])==set(map(str,range(5)))
 print(json.dumps({'status':'passed','files':len(manifest),'train_rows':report['train_rows'],'val_rows':report['val_rows'],'threshold_validation_scores':1050,'historical_full_and_matched_random_seed_tables':15,'followup_seed_tables':15,'localization_model_seeds':10}))
if __name__=='__main__':main()
