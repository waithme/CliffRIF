#!/usr/bin/env python3
"""Read-only checks of saved canonical identities and pair-reference partitions.

This does not canonicalize chemistry, rebuild labels, or certify exclusion of
official test identities. It validates the stored development JSONL files.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def load_records(path: Path, expected_split: str):
    rows = []
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for line_number, raw in enumerate(handle, 1):
            digest.update(raw)
            if not raw.strip():
                continue
            row = json.loads(raw)
            if not row.get("dataset") or not isinstance(row.get("row_idx"), int):
                raise ValueError(f"{path}:{line_number}: missing dataset or integer row_idx")
            if not isinstance(row.get("canonical_smiles"), str) or not row["canonical_smiles"]:
                raise ValueError(f"{path}:{line_number}: missing stored canonical_smiles")
            if row.get("split") != expected_split:
                raise ValueError(f"{path}:{line_number}: expected split={expected_split}")
            rows.append(row)
    if not rows:
        raise ValueError(f"Empty development partition: {path}")
    return rows, digest.hexdigest()


def audit_region_files(train_file: Path, val_file: Path):
    train, train_sha = load_records(Path(train_file), "train")
    val, val_sha = load_records(Path(val_file), "val")
    train_ids = {r["canonical_smiles"] for r in train}
    val_ids = {r["canonical_smiles"] for r in val}
    train_keys = {(r["dataset"], r["row_idx"]) for r in train}
    val_keys = {(r["dataset"], r["row_idx"]) for r in val}
    missing_references = 0
    wrong_reference_split = 0
    for row in train + val:
        for region in row.get("regions", []):
            for reference in region.get("references", []):
                if (row["dataset"], reference.get("row_idx")) not in train_keys:
                    missing_references += 1
                if reference.get("split") != "train":
                    wrong_reference_split += 1
    errors = []
    overlap = train_ids & val_ids
    if overlap:
        errors.append(f"global train/validation identity overlap: {len(overlap)}")
    if train_keys & val_keys:
        errors.append(f"train/validation source-row overlap: {len(train_keys & val_keys)}")
    if len(train_keys) != len(train) or len(val_keys) != len(val):
        errors.append("duplicate dataset/row_idx within a partition")
    if missing_references or wrong_reference_split:
        errors.append(f"invalid pair references: absent={missing_references}, nontrain={wrong_reference_split}")
    return {
        "passed": not errors,
        "scope": "stored development identities and reference partitions only; no official-test or chemistry verification",
        "train_file": str(Path(train_file).resolve()),
        "val_file": str(Path(val_file).resolve()),
        "train_sha256": train_sha,
        "val_sha256": val_sha,
        "train_rows": len(train),
        "val_rows": len(val),
        "train_unique_identities": len(train_ids),
        "val_unique_identities": len(val_ids),
        "global_identity_overlap": len(overlap),
        "missing_train_references": missing_references,
        "nontrain_references": wrong_reference_split,
        "per_target_train": dict(sorted(Counter(r["dataset"] for r in train).items())),
        "per_target_val": dict(sorted(Counter(r["dataset"] for r in val).items())),
        "errors": errors,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train_file", required=True, type=Path)
    parser.add_argument("--val_file", required=True, type=Path)
    parser.add_argument("--output", type=Path, help="Optional new report path; refuses to overwrite")
    args = parser.parse_args()
    report = audit_region_files(args.train_file, args.val_file)
    content = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        with args.output.open("x", encoding="utf-8") as handle:
            handle.write(content)
    print(content, end="")
    raise SystemExit(0 if report["passed"] else 2)


if __name__ == "__main__":
    main()
