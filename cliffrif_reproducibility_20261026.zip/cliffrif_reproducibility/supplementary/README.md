# Supplementary reproducibility materials

Core model, feature and training files are byte-identical to the recorded runs;
see `source_provenance.json`. `run_control.py` is a portable launcher prepared
for this release, with dry-run as its default. It preserves outputs and refuses
to overwrite an existing output root. It does not run external baselines.
Install the environment described in the package root. Use Python 3.10 and
RDKit 2023.09.6 for the recorded environment; CUDA/PyTorch wheels must match the host.

From the **package root**, with official MoleculeACE CSVs obtained at the
reference commit listed in the root README:

```bash
python supplementary/run_control.py gine3_only --dataset_dir /absolute/path/to/CSVs --output_root /absolute/path/to/new/gine3
python supplementary/run_control.py random_region --dataset_dir /absolute/path/to/CSVs --output_root /absolute/path/to/new/random
python supplementary/run_control.py scratch_property --dataset_dir /absolute/path/to/CSVs --output_root /absolute/path/to/new/scratch_property
python supplementary/run_control.py scratch_full --dataset_dir /absolute/path/to/CSVs --output_root /absolute/path/to/new/scratch_full
python supplementary/run_control.py skip_unsupported --dataset_dir /absolute/path/to/CSVs --output_root /absolute/path/to/new/skip
python supplementary/run_control.py nominal --dataset_dir /absolute/path/to/CSVs --output_root /absolute/path/to/new/nominal
python supplementary/run_control.py gap08 --dataset_dir /absolute/path/to/CSVs --output_root /absolute/path/to/new/gap08
```

Commands above only print commands and input hashes. Add `--execute` to train.
Defaults are five model seeds 0–4 and all 30 targets. Other threshold modes are
`gap12`, `similarity_low`, `similarity_high`, `mcs055`, and `mcs065`. All seven
threshold modes force validation-only execution; they never evaluate official
test graphs or write test predictions. Original thresholds remain unchanged.
For each mode pooled pretraining still uses all development training rows,
even if `--datasets` restricts the later target fine-tuning.

Scratch property/full use the same seed-controlled initialization, no pooled
pretraining, and property-only versus joint losses during target fine-tuning.
Skip-unsupported masks unsupported auxiliary losses but retains regression;
this creates a limitation for existence supervision because trustworthy
negative auxiliary labels are not supplied. Random regions retain original
existence labels, mask size and connected-component sizes with label seed 0.
The threshold settings change only one construction parameter family at a time:
gap .8/1.2 versus 1.0; primary/fallback similarity .88/.83 or .92/.87 versus
.90/.85; MCS core fraction .55/.65 versus .60. Validation checkpoints are
selected by activity RMSE. No test-based threshold selection is performed.

## Result records

`results/` includes 15 follow-up per-seed tables (scratch property/full and
skip-unsupported), all 35 threshold seed tables, threshold target comparisons,
and localization aggregates plus all 30 targets for the two models in SI.
The root `results/` has five seeds each for historical Full, matched GINE3
Only, and random regions. The six non-nominal threshold seed-0 runs were reused
from the earlier completed suite; 29 other seed runs were new. Do not describe
all 35 as newly trained together. Changes between model seeds do not change
annotation realizations or development splits.

For localization, first finish scratch_full and skip_unsupported with output
roots `<NEW_RUNS>/runs/<mode>`; each then contains `seed_<s>/targets/<target>/best.pt`.
Set `CLIFFRIF_FOLLOWUP_RUNS=<NEW_RUNS>` and
`CLIFFRIF_VAL_FILE=<PACKAGE>/data/val_regions.jsonl`, and run
`python supplementary/followup/code/analyze_localization.py` without `--smoke`.
This diagnostic compares the direct mask with absolute Input×Gradient from
**the same model**, selecting the known reference number of atoms for each.
There are 3,416 validation rows and 1,305 positive references per seed; overlap
metrics are averaged over positive references. It is an oracle-size validation
diagnostic against computed labels, not causal-site validation, deployment
accuracy, or localization by the original historical Full checkpoint.

Fixed supplementary JSONL inputs, when included, are listed in
`fixed_input_manifest.json`. Use those exact files for the published comparisons:
a new MCS search under a timeout may change labels. All numerical scores remain
unchanged; only host-specific checkpoint paths were removed from public tables.
