"""Fixed, size/component-matched random mask control. No global RNG mutation."""
import hashlib,json,random

def components(atoms,adj):
 unseen=set(atoms);out=[]
 while unseen:
  todo=[min(unseen)];unseen.remove(todo[0]);found=[]
  while todo:
   v=todo.pop();found.append(v)
   for w in sorted(adj[v]):
    if w in unseen:unseen.remove(w);todo.append(w)
  out.append(sorted(found))
 return sorted(out,key=lambda x:(-len(x),x))

def connected_grow(size,allowed,adj,rng):
 if not allowed:return None
 selected={rng.choice(sorted(allowed))}
 while len(selected)<size:
  frontier=set().union(*(adj[v] for v in selected)) & allowed - selected
  if not frontier:return None
  selected.add(rng.choice(sorted(frontier)))
 return selected

def make_random_mask(original_atoms,adj,key,label_seed=0,attempts=64):
 original=set(original_atoms)
 if not original:return [],{'fallback_original':False,'attempts':0,'same_mask':True,'components':[]}
 sizes=sorted((len(x) for x in components(original,adj)),reverse=True)
 seed=int.from_bytes(hashlib.sha256(json.dumps([label_seed,key],ensure_ascii=True,separators=(',',':')).encode()).digest()[:16],'big')
 rng=random.Random(seed)
 for attempt in range(1,attempts+1):
  selected=set();ok=True
  for size in sizes:
   forbidden=selected|set().union(*(adj[v] for v in selected)) if selected else set()
   part=connected_grow(size,set(range(len(adj)))-forbidden,adj,rng)
   if part is None:ok=False;break
   selected.update(part)
  if ok and sorted((len(x) for x in components(selected,adj)),reverse=True)==sizes:
   return sorted(selected),{'fallback_original':False,'attempts':attempt,'same_mask':selected==original,'components':sizes}
 # Never silently relax label size/connectivity or discard a molecule.
 # The generator records these constrained failures; a pretraining gate caps them.
 return sorted(original),{'fallback_original':True,'attempts':attempts,'same_mask':True,'components':sizes}
