#!/usr/bin/env python3
"""Recorded follow-up models: validation-only, size-matched mask/attribution diagnostic."""
from pathlib import Path
import argparse,json,os,time,traceback,csv,math
from collections import defaultdict
import numpy as np
import torch
from torch_geometric.data import Batch
from sklearn.metrics import roc_auc_score,average_precision_score,f1_score
from gine_region_detector import MultiScaleRegionConfig,GINEMultiScaleRegionDetector
from train_gine_region_detector import row_to_data
ROOT=Path(os.environ['CLIFFRIF_FOLLOWUP_RUNS']).resolve();ORIG=Path(os.environ['CLIFFRIF_VAL_FILE']).resolve()
def metrics(pred,ref):
 inter=len(pred&ref);union=len(pred|ref)
 return {'iou':inter/union if union else 1.,'dice':2*inter/(len(pred)+len(ref)) if pred or ref else 1.}
def main():
 p=argparse.ArgumentParser();p.add_argument('--smoke',action='store_true');args=p.parse_args();torch.set_num_threads(2)
 rows=[json.loads(l) for l in ORIG.open()];assert len(rows)==3416
 by=defaultdict(list)
 for r in rows:by[r['dataset']].append(r)
 outdir=ROOT/'localization';outdir.mkdir(exist_ok=True);records=[];macros={};target_metrics={}
 modes=['scratch_property'] if args.smoke else ['scratch_full','skip_unsupported']
 for mode in modes:
  seeds=[0] if args.smoke else range(5)
  for seed in seeds:
   save_rows=[];target_rows=[]
   datasets=[sorted(by)[0]] if args.smoke else sorted(by)
   for name in datasets:
    checkpoint=ROOT/'runs'/mode/f'seed_{seed}'/'targets'/name/'best.pt';c=torch.load(checkpoint,map_location='cpu',weights_only=False)
    cfg=MultiScaleRegionConfig(**c['model_config']);m=GINEMultiScaleRegionDetector(cfg).cuda().eval();m.load_state_dict(c['model_state_dict'],strict=True);tid=int(c['task_to_index'][name])
    rr=([next(r for r in by[name] if r['cliff_existence_label']==0),next(r for r in by[name] if r['cliff_existence_label']==1)] if args.smoke else by[name]);individual=[]
    for start in range(0,len(rr),64):
     rs=rr[start:start+64];items=[row_to_data(r,tid,3) for r in rs];b=Batch.from_data_list(items).to('cuda');b.x=b.x.float().requires_grad_(True)
     v=m(b);g=torch.autograd.grad(v['y_pred'].sum(),b.x)[0];attr=(g*b.x).abs().sum(dim=1).detach();prob=torch.sigmoid(v['mask_logits'][0]).detach();exist=torch.sigmoid(v['region_existence_logit']).detach()
     assert torch.isfinite(attr).all() and torch.isfinite(prob).all() and torch.isfinite(exist).all()
     for i,r in enumerate(rs):
      a,z=int(b.ptr[i]),int(b.ptr[i+1]);ref=set(torch.nonzero(b.mask_target[a:z,0]>.5).view(-1).tolist());k=len(ref)
      pred=set(torch.nonzero(prob[a:z]>=.5).view(-1).tolist());exists=float(exist[i])>=.5
      row={'mode':mode,'seed':seed,'dataset':name,'row_idx':r['row_idx'],'existence_true':int(r['cliff_existence_label']),'existence_probability':float(exist[i]),'reference_atoms':k,'predicted_atoms_at_05':len(pred),'oracle_size':True}
      if k:
       pm=set(torch.argsort(prob[a:z],descending=True,stable=True)[:k].tolist());pa=set(torch.argsort(attr[a:z],descending=True,stable=True)[:k].tolist());x=metrics(pm,ref);y=metrics(pa,ref)
       row.update({'mask_topk_iou':x['iou'],'mask_topk_dice':x['dice'],'inputxgradient_topk_iou':y['iou'],'inputxgradient_topk_dice':y['dice'],'mask_threshold_iou':metrics(pred,ref)['iou'],'all_attributions_zero':bool((attr[a:z]==0).all())})
       row['category']='correct' if exists and pred and row['mask_threshold_iou']>=.5 else ('below_iou' if exists and pred else 'missed')
      else:row['category']='false_positive' if exists and pred else 'no_reference'
      individual.append(row);save_rows.append(row)
    positives=[r for r in individual if r['reference_atoms']];y=[r['existence_true'] for r in individual];yp=[r['existence_probability'] for r in individual]
    tr={'dataset':name,'rows':len(individual),'positives':len(positives),'existence_auroc':roc_auc_score(y,yp) if len(set(y))==2 else None,'existence_auprc':average_precision_score(y,yp) if sum(y)>0 else None,'existence_f1':f1_score(y,np.array(yp)>=.5,zero_division=0)}
    for key in ['mask_topk_iou','mask_topk_dice','inputxgradient_topk_iou','inputxgradient_topk_dice','mask_threshold_iou']:tr[key]=float(np.mean([r[key] for r in positives])) if positives else None
    target_rows.append(tr);del m
   keys=sorted(set().union(*(r.keys() for r in save_rows)))
   with (outdir/f'{mode}_seed_{seed}.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(save_rows)
   macro={k:(float(np.mean([r[k] for r in target_rows if r[k] is not None])) if any(r[k] is not None for r in target_rows) else None) for k in ['existence_auroc','existence_auprc','existence_f1','mask_topk_iou','mask_topk_dice','inputxgradient_topk_iou','inputxgradient_topk_dice','mask_threshold_iou']}
   macros.setdefault(mode,{})[seed]=macro;target_metrics.setdefault(mode,{})[seed]=target_rows
   if not args.smoke:assert len(save_rows)==3416 and sum(r['reference_atoms']>0 for r in save_rows)==1305
 result={'scope':'Newly recorded follow-up checkpoints only; not original canonical Full. Validation rows used in activity checkpoint selection. Top-k comparisons use the same model and oracle reference size without existence gating; threshold diagnostics reported separately. Absolute Input×Gradient on property input features is a simple reference, not a chemical ground truth.','smoke_only':args.smoke,'seed_macros':macros,'per_target':target_metrics}
 (outdir/('smoke.json' if args.smoke else 'aggregate.json')).write_text(json.dumps(result,indent=2,allow_nan=False));print(json.dumps({'smoke':args.smoke,'models':list(macros),'finite_gradient_diagnostic':'passed'}))
if __name__=='__main__':
 start=time.time();status=ROOT/'localization_status.json'
 try:
  main();status.write_text(json.dumps({'status':'complete','exit_code':0,'elapsed_seconds':time.time()-start,'smoke_only':'--smoke' in os.sys.argv}))
 except Exception:
  status.write_text(json.dumps({'status':'failed','error':traceback.format_exc()}));raise
