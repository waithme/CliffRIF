#!/usr/bin/env python3
"""Portable release launcher: dry-run by default; unchanged scientific core files."""
import argparse,csv,hashlib,json,os,subprocess,sys,time
from pathlib import Path
PACKAGE=Path(__file__).resolve().parents[1]
THRESHOLDS=['nominal','gap08','gap12','similarity_low','similarity_high','mcs055','mcs065']
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('mode',choices=['gine3_only','random_region','scratch_property','scratch_full','skip_unsupported',*THRESHOLDS])
 p.add_argument('--dataset_dir',required=True,type=Path)
 p.add_argument('--output_root',required=True,type=Path)
 p.add_argument('--seeds',nargs='+',type=int,default=list(range(5)))
 p.add_argument('--datasets',nargs='+')
 p.add_argument('--device',default='cuda')
 p.add_argument('--execute',action='store_true')
 a=p.parse_args();out=a.output_root.resolve();csvdir=a.dataset_dir.resolve()
 assert not out.exists(),'Refuse to overwrite an existing output directory'
 assert len(a.seeds)==len(set(a.seeds)) and all(s in range(5) for s in a.seeds)
 mode=a.mode;group=mode if mode in ['gine3_only','random_region'] else 'followup'
 code=PACKAGE/'supplementary'/group/'code'
 data=PACKAGE/'data'
 if mode=='random_region':data=PACKAGE/'supplementary/random_region_data'
 elif mode in THRESHOLDS and mode!='nominal':data=PACKAGE/'supplementary/threshold_data'/mode
 train=data/'train_regions.jsonl';val=data/'val_regions.jsonl'
 rows=[json.loads(l) for l in train.open()];vrows=[json.loads(l) for l in val.open()]
 assert len(rows)==30403 and len(vrows)==3416
 names=sorted({r['dataset'] for r in rows});assert len(names)==30
 selected=a.datasets or names;assert len(selected)==len(set(selected)) and set(selected)<=set(names)
 assert not ({r['canonical_smiles'] for r in rows}&{r['canonical_smiles'] for r in vrows})
 manifest=json.loads((PACKAGE/'release_manifest.json').read_text())
 for f in [train,val,*code.glob('*.py')]:
  k=str(f.relative_to(PACKAGE));assert hashlib.sha256(f.read_bytes()).hexdigest()==manifest[k]['sha256'],k
 if a.execute:
  assert all((csvdir/(n+'.csv')).is_file() for n in names),'Supply all official source CSVs'
  out.mkdir(parents=True,exist_ok=False)
  (out/'input_record.json').write_text(json.dumps({'mode':mode,'seeds':a.seeds,'selected_targets':selected,'pooled_training_targets':names,'fixed_split_seed':0,'train_sha256':hashlib.sha256(train.read_bytes()).hexdigest(),'val_sha256':hashlib.sha256(val.read_bytes()).hexdigest(),'core_hashes':{str(f.relative_to(PACKAGE)):hashlib.sha256(f.read_bytes()).hexdigest() for f in code.glob('*.py')},'python':sys.version,'validation_only':mode in THRESHOLDS},indent=2))
 env=os.environ.copy();env.update(CLIFFRIF_CONTROL=mode,CLIFFRIF_VALIDATION_ONLY='1' if mode in THRESHOLDS else '0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1')
 def run(cmd,stage):
  print(json.dumps({'stage':stage,'command':cmd,'validation_only':env['CLIFFRIF_VALIDATION_ONLY'],'control':mode}),flush=True)
  if not a.execute:return
  log=out/'logs'/f'{stage}.log';log.parent.mkdir(exist_ok=True)
  with log.open('x') as f:r=subprocess.run(cmd,cwd=code,env=env,stdout=f,stderr=subprocess.STDOUT)
  with (out/'commands.jsonl').open('a') as f:f.write(json.dumps({'stage':stage,'command':cmd,'exit_code':r.returncode,'finished_unix':time.time()})+'\n')
  if r.returncode:raise RuntimeError(f'{stage} failed; see {log}')
 aux='0' if mode in ['gine3_only','scratch_property'] else '0.5'
 common=['--data_file',str(train),'--val_data_file',str(val),'--epochs','100','--batch_size','128','--patience','15','--weight_decay','1e-5','--grad_clip','5','--lambda_y','1','--lambda_mask',aux,'--lambda_exist',aux,'--num_workers','0','--device',a.device]
 for seed in a.seeds:
  sd=out/f'seed_{seed}';ck=sd/'pretrain/best.pt'
  if mode.startswith('scratch_'):
   ck=sd/'initialization.pt'
   print(json.dumps({'stage':f'seed_{seed}_initialization','seed':seed,'hidden_dim':300,'layers':3,'dropout':0.1,'task_to_index':{n:i for i,n in enumerate(names)}}))
   if a.execute:
    import torch
    from dataclasses import asdict
    sys.path.insert(0,str(code))
    from gine_region_detector import MultiScaleRegionConfig,GINEMultiScaleRegionDetector
    torch.manual_seed(seed);cfg=MultiScaleRegionConfig(35,12,30,target_conditioned=False);m=GINEMultiScaleRegionDetector(cfg)
    sd.mkdir(parents=True,exist_ok=False)
    torch.save({'model_state_dict':m.state_dict(),'model_config':asdict(cfg),'task_to_index':{n:i for i,n in enumerate(names)},'initialization_only':True,'seed':seed},ck)
  else:run([sys.executable,'-B',str(code/'train_gine_region_detector.py'),*common,'--output_dir',str(sd/'pretrain'),'--seed',str(seed),'--lr','0.001','--hidden_dim','300','--num_layers','3','--dropout','0.1'],f's{seed}_pretrain')
  summary=[]
  for name in selected:
   target=sd/'targets'/name
   run([sys.executable,'-B',str(code/'finetune_gine_region_detector.py'),*common,'--dataset_dir',str(csvdir),'--dataset',name,'--checkpoint',str(ck),'--output_dir',str(target),'--seed',str(seed),'--lr','0.0001'],f's{seed}_{name}')
   if a.execute:
    m=json.loads((target/'final_metrics.json').read_text())
    if mode in THRESHOLDS:assert m['validation_only'] is True and m['n_official_test']==0 and not (target/'test_predictions.csv').exists()
    summary.append(m)
  if a.execute:
   keys=sorted(set().union(*(r.keys() for r in summary)))
   with (sd/'summary.csv').open('x') as f:
    w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in summary)
 if a.execute:(out/'status.json').write_text(json.dumps({'status':'complete','exit_code':0,'mode':mode,'completed_targets':len(a.seeds)*len(selected)}))
if __name__=='__main__':main()
