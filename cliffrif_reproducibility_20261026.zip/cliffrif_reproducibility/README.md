# Audited CliffRIF canonical workflow

This package separates the equal-region, mean-pooling model and pair-derived
v2 annotations from earlier implementations. Root-level generators elsewhere
in the repository are legacy paths and are not the canonical inputs here.

The frozen JSONL files are the authoritative reproducibility inputs: 30,403
training rows and 3,416 validation rows, globally separated by canonical
identity (split seed 0). Train SHA-256 is
`2a803f1f7295813c6f90d0833c4c8c57ca53b696dc15a906ac37e9361630fcbc`;
validation SHA-256 is
`5b90f19273e89ea40329adbcea45a00f051a642f415b03deca8ff7da7a793fa8`.
`data/split_manifest.csv` supplies every row assignment. Labels are derived
from qualifying localized pairs; the output field `cliff_mol` in these files
is derived and is not the original official cliff annotation.

The data archive contains the unmodified JSONL files, split manifest,
generator, recorded generator summary, data audits, and five-seed Full/GINE3/
random-region score records. It excludes external baseline implementations
and results. MoleculeACE attribution and license are retained. Obtain the
official source CSVs from https://github.com/molML/MoleculeACE at commit
`7e6de0bd2968c56589c580f2a397f01c531ede26`; official test cliff flags are used
only in final evaluation. RDKit 2023.09.6 was used for the audited construction.

## Verify and run

After extracting the reproducibility archive, change into this directory. Then:

```bash
python tools/audit_region_data.py --train_file data/train_regions.jsonl --val_file data/val_regions.jsonl
python model/run_multi_ablation.py final --train_file data/train_regions.jsonl --val_file data/val_regions.jsonl --dataset_dir /path/to/MoleculeACE_CSVs --output_root /path/to/new_outputs --seeds 0 1 2 3 4
```

The published launcher requires explicit data/output paths, checks identity
separation, and preserves checkpoints, predictions, command/environment
records and workspaces by default. It differs only in orchestration from the
archived historical launcher, which discarded temporary workspaces. The
training/model source files are byte-identical to the audited equal-region
candidate; see `original_source_manifest.json` and `release_manifest.json`.
Use `--dry_run` to inspect commands without training. No baseline is invoked.

## Construction and scientific scope

For a reconstruction in a separate directory, use the generator with explicit
`--val_split_seed 0 --max_regions_per_mol 12`. Its default region cap is 16;
the frozen files have actual maxima 9/5, so the reported cap of 12 did not
truncate them. MCS has bounded attempts and a one-second timeout: a rerun under
another toolkit or runtime may not be byte-identical. Verify frozen hashes
rather than asserting exact re-generation from defaults alone.

The support labels are computational proxies, not chemical negatives or
mechanistic truth. Shared-target label conflicts and support-cause counts are
included as audits. The random-region control preserves existence labels and
uses one fixed label realization; it tests location under those constraints.
Full historical score provenance is documented, but the complete original
per-run CLI and checkpoint set was not recovered. No new Full run is implied.


## Supplementary experiments

`supplementary/README.md` describes the matched property-only model, fixed random
regions, scratch training, unsupported-label control, five-seed annotation
threshold sensitivity and validation localization diagnostic. The four core
model/training/feature files for each experiment are unchanged snapshots;
portable launch orchestration and the diagnostic path adaptation are identified
in `supplementary/source_provenance.json`.

`python tools/verify_release.py` verifies every distributed file against
`release_manifest.json` using SHA-256, checks the frozen split files, and checks
completeness of the distributed seed summaries. The manifest excludes itself.

The package does not contain historical Full checkpoints/per-molecule
predictions, external baseline code/results, or checkpoints for the new runs.
The original Full execution chain was not fully retained; the included scores
must not be presented as a fresh rerun. New checkpoints can be produced by the
published workflow. All result comparisons are descriptive. Model-seed SDs
refer to one fixed development split and one fixed label realization per setting.
