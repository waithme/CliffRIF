#!/usr/bin/env python3
"""Build MoleculeACE pair-derived cliff and region supervision.

Design rules
------------
1. The input CSV ``cliff_mol`` label is neither required nor read. Existence
   labels are derived only from successfully localized molecular pairs.
2. Strict candidate pairs follow MoleculeACE: potency difference > 10-fold
   (equivalent to ``abs(delta_y) > 1`` for pKi/pEC50) and at least one of
   Morgan-Tanimoto, generic-scaffold-Tanimoto, or normalized SMILES
   Levenshtein similarity >= 0.9. Molecules still uncovered after strict-pair
   localization may use a lower-confidence fallback pair with similarity >=
   0.85.
3. A candidate pair is accepted only when the structural change can be
   localized on both molecules. If a->b replaces group A with group B, group A
   is the region on a and group B is the region on b; both molecules are
   labeled positive.
4. Regions are localized first with the single-cut MMP procedure and then, if
   needed, with a conservative bilateral MCS fallback. Weak fallback pairs
   carry reduced supervision confidence. Unlocalized candidates do not create
   positive labels.
5. All official test molecules are removed before fragmentation,
   train/validation splitting, or region localization. Test canonical SMILES
   are collected globally across targets, and matching training rows in every
   target are also removed to prevent cross-target molecule leakage.
6. The remaining official training molecules are divided once at the global
   canonical-SMILES level. Consequently, a molecule shared by several targets
   is assigned to the same final-train or validation subset in every target.
   Train pairs are symmetric within subtrain. Validation molecules search for
   bilateral matches in subtrain, but only the validation side is written, so
   validation information never changes train labels.
7. Test molecules, including train rows matching a test molecule from another
   target, are never fragmented, localized, used as references, or written by
   this script.

Example
-------
python build_moleculeace_official_region_datav2.py \
  --input_dir data/moleculeace \
  --output data/moleculeace_official_train_regions.jsonl
"""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import pandas as pd
from Levenshtein import distance as levenshtein_distance
from rdkit import Chem, DataStructs, RDLogger
from rdkit.Chem import AllChem
from rdkit.Chem import rdFMCS
from rdkit.Chem.Scaffolds.MurckoScaffold import GetScaffoldForMol, MakeScaffoldGeneric
from sklearn.model_selection import train_test_split

RDLogger.DisableLog("rdApp.warning")

# Similar to the default RDKit MMPA cut pattern: non-ring, non-multiple,
# carbon-side cut.
CUT_BOND_SMARTS = '[#6+0;!$(*=,#[!#6])]!@!=!#[*]'


def safe_mol_from_smiles(smiles: str, sanitize: bool = True) -> Optional[Chem.Mol]:
    if not isinstance(smiles, str) or not smiles.strip():
        return None
    try:
        mol = Chem.MolFromSmiles(smiles, sanitize=sanitize)
        if mol is not None:
            return mol
    except Exception:
        pass
    try:
        mol = Chem.MolFromSmiles(smiles, sanitize=False)
        if mol is None:
            return None
        try:
            Chem.SanitizeMol(
                mol,
                sanitizeOps=(
                    Chem.SanitizeFlags.SANITIZE_ALL
                    ^ Chem.SanitizeFlags.SANITIZE_KEKULIZE
                ),
            )
        except Exception:
            pass
        return mol
    except Exception:
        return None


def canonicalize_smiles(smiles: str) -> Optional[str]:
    mol = safe_mol_from_smiles(smiles, sanitize=True)
    if mol is None:
        return None
    try:
        return Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True)
    except Exception:
        return None


def mol_to_smiles_no_sanitize(mol: Chem.Mol) -> Optional[str]:
    try:
        return Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True)
    except Exception:
        try:
            return Chem.MolToSmiles(mol, canonical=False, isomericSmiles=True)
        except Exception:
            return None


def heavy_atom_count_in_original_atoms(
    mol: Chem.Mol, atom_ids: Sequence[int]
) -> int:
    return sum(
        1 for atom_id in atom_ids
        if mol.GetAtomWithIdx(int(atom_id)).GetAtomicNum() > 1
    )


def candidate_cut_bond_indices(mol: Chem.Mol) -> List[int]:
    """Return MMP-like cuttable bond indices with a conservative fallback."""
    bond_ids = set()
    pattern = Chem.MolFromSmarts(CUT_BOND_SMARTS)
    if pattern is not None:
        for atom_a, atom_b in mol.GetSubstructMatches(pattern):
            bond = mol.GetBondBetweenAtoms(int(atom_a), int(atom_b))
            if bond is not None:
                bond_ids.add(bond.GetIdx())
    if bond_ids:
        return sorted(bond_ids)

    for bond in mol.GetBonds():
        if bond.IsInRing() or bond.GetBondType() != Chem.BondType.SINGLE:
            continue
        atom_a = bond.GetBeginAtom()
        atom_b = bond.GetEndAtom()
        if atom_a.GetAtomicNum() <= 1 or atom_b.GetAtomicNum() <= 1:
            continue
        bond_ids.add(bond.GetIdx())
    return sorted(bond_ids)


def choose_center_and_radius(
    mol: Chem.Mol, sub_atoms: Sequence[int], max_radius: int
) -> Tuple[int, int]:
    """Choose a stable fragment center and its capped graph radius."""
    sub_atoms = [int(atom) for atom in sub_atoms]
    if not sub_atoms:
        return -1, 0
    if len(sub_atoms) == 1:
        return sub_atoms[0], 1
    try:
        distances = Chem.GetDistanceMatrix(mol)
        scored = []
        for atom in sub_atoms:
            atom_distances = [int(distances[atom, other]) for other in sub_atoms]
            scored.append((
                max(atom_distances),
                sum(atom_distances) / len(atom_distances),
                atom,
            ))
        scored.sort()
        center = int(scored[0][2])
        real_radius = max(int(distances[center, atom]) for atom in sub_atoms)
        return center, max(1, min(int(real_radius), int(max_radius)))
    except Exception:
        return sub_atoms[0], 1


def fragment_molecule_single_cut_with_indices(
    smiles: str,
    min_core_atoms: int = 3,
    max_sub_heavy_atoms: Optional[int] = 20,
    max_radius: int = 3,
) -> List[dict]:
    """Create single-cut core/sub records while preserving original indices."""
    canonical = canonicalize_smiles(smiles)
    if canonical is None:
        return []
    mol = safe_mol_from_smiles(canonical, sanitize=True)
    if mol is None:
        return []

    num_original_atoms = mol.GetNumAtoms()
    output = []
    seen = set()
    for bond_idx in candidate_cut_bond_indices(mol):
        bond = mol.GetBondWithIdx(int(bond_idx))
        atom_a = int(bond.GetBeginAtomIdx())
        atom_b = int(bond.GetEndAtomIdx())
        try:
            fragmented = Chem.FragmentOnBonds(
                mol,
                [int(bond_idx)],
                addDummies=True,
                dummyLabels=[(1, 1)],
            )
            fragment_atom_tuples = Chem.GetMolFrags(
                fragmented, asMols=False, sanitizeFrags=False
            )
            fragment_mols = Chem.GetMolFrags(
                fragmented, asMols=True, sanitizeFrags=False
            )
        except Exception:
            continue
        if len(fragment_atom_tuples) != 2 or len(fragment_mols) != 2:
            continue

        sides = []
        for fragment_index, atom_tuple in enumerate(fragment_atom_tuples):
            original_atoms = sorted(
                int(atom) for atom in atom_tuple
                if int(atom) < num_original_atoms
            )
            if not original_atoms:
                continue
            fragment_smiles = mol_to_smiles_no_sanitize(
                fragment_mols[fragment_index]
            )
            if not fragment_smiles:
                continue
            sides.append({
                "atoms": original_atoms,
                "smi": fragment_smiles,
                "heavy": heavy_atom_count_in_original_atoms(
                    mol, original_atoms
                ),
            })
        if len(sides) != 2:
            continue

        if (sides[0]["heavy"], sides[0]["smi"]) >= (
            sides[1]["heavy"], sides[1]["smi"]
        ):
            core_side, sub_side = sides[0], sides[1]
        else:
            core_side, sub_side = sides[1], sides[0]
        if core_side["heavy"] < min_core_atoms:
            continue
        if (
            max_sub_heavy_atoms is not None
            and sub_side["heavy"] > max_sub_heavy_atoms
        ):
            continue
        if core_side["smi"] == sub_side["smi"]:
            continue

        core_atoms = sorted(core_side["atoms"])
        sub_atoms = sorted(sub_side["atoms"])
        if atom_a in core_atoms and atom_b in sub_atoms:
            connection_atom_core, connection_atom_sub = atom_a, atom_b
        elif atom_b in core_atoms and atom_a in sub_atoms:
            connection_atom_core, connection_atom_sub = atom_b, atom_a
        else:
            continue

        center_atom, radius = choose_center_and_radius(
            mol, sub_atoms, max_radius=max_radius
        )
        if center_atom < 0:
            continue
        key = (
            core_side["smi"],
            sub_side["smi"],
            tuple(sub_atoms),
            int(bond_idx),
        )
        if key in seen:
            continue
        seen.add(key)
        output.append({
            "core": core_side["smi"],
            "sub": sub_side["smi"],
            "core_atoms": core_atoms,
            "sub_atoms": sub_atoms,
            "connection_bond_idx": int(bond_idx),
            "connection_bond": [atom_a, atom_b],
            "connection_atom_core": int(connection_atom_core),
            "connection_atom_sub": int(connection_atom_sub),
            "center_atom": int(center_atom),
            "radius": int(radius),
            "localization_valid": True,
        })
    return sorted(
        output,
        key=lambda item: (
            item["core"], item["sub"], item["connection_bond_idx"]
        ),
    )


def canonicalize(value):
    mol = Chem.MolFromSmiles(str(value)) if value is not None else None
    return Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True) if mol is not None else None


def finite_float(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def generic_scaffold_fp(mol, radius, nbits):
    try:
        scaffold = MakeScaffoldGeneric(mol)
    except Exception:
        scaffold = GetScaffoldForMol(mol)
    return AllChem.GetMorganFingerprintAsBitVect(scaffold, radius=radius, nBits=nbits)


def normalized_levenshtein_similarity(a, b):
    denominator = max(len(a), len(b))
    return 1.0 if denominator == 0 else 1.0 - levenshtein_distance(a, b) / denominator


def official_similarity(a, b, threshold):
    """Return whether a pair passes any official similarity and its details."""
    tani = DataStructs.TanimotoSimilarity(a["fp"], b["fp"])
    scaffold = DataStructs.TanimotoSimilarity(a["scaffold_fp"], b["scaffold_fp"])
    lev = normalized_levenshtein_similarity(a["smiles"], b["smiles"])
    methods = []
    if tani >= threshold:
        methods.append("morgan_tanimoto")
    if scaffold >= threshold:
        methods.append("scaffold_tanimoto")
    if lev >= threshold:
        methods.append("smiles_levenshtein")
    return bool(methods), {
        "similarity_methods": methods,
        "morgan_tanimoto": tani,
        "scaffold_tanimoto": scaffold,
        "smiles_levenshtein": lev,
        "max_similarity": max(tani, scaffold, lev),
    }


def read_dataset(path, args):
    frame = pd.read_csv(path)
    required = [args.smiles_col, args.y_col, args.split_col]
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise ValueError(f"{path}: missing columns {missing}; available={list(frame.columns)}")

    rows, invalid = [], 0
    for row_index, raw in frame.iterrows():
        smiles = canonicalize(raw[args.smiles_col])
        y = finite_float(raw[args.y_col])
        split = str(raw[args.split_col]).strip().lower()
        if smiles is None or y is None or split not in {"train", "test"}:
            invalid += 1
            continue
        mol = Chem.MolFromSmiles(smiles)
        rows.append({
            "dataset": path.stem,
            "row_idx": int(row_index),
            "smiles": smiles,
            "canonical_smiles": smiles,
            "y": y,
            "split": split,
            "mol": mol,
            "fp": AllChem.GetMorganFingerprintAsBitVect(mol, radius=args.fp_radius, nBits=args.fp_bits),
            "scaffold_fp": generic_scaffold_fp(mol, args.fp_radius, args.fp_bits),
        })
    return rows, invalid


def fragment_rows(rows, args):
    cache = {}
    for row in rows:
        smiles = row["smiles"]
        if smiles not in cache:
            cache[smiles] = fragment_molecule_single_cut_with_indices(
                smiles,
                min_core_atoms=args.min_core_atoms,
                max_sub_heavy_atoms=args.max_sub_heavy_atoms,
                max_radius=args.max_radius,
            )
        row["fragments"] = cache[smiles]


def split_global_canonical_smiles(canonical_smiles, val_ratio, split_seed):
    """Assign each unique molecule to one globally consistent train/val set."""
    if not 0.0 < val_ratio < 1.0:
        raise ValueError(f"val_ratio must be between 0 and 1, got {val_ratio}")
    unique_smiles = sorted(set(canonical_smiles))
    if len(unique_smiles) < 2:
        raise ValueError(
            "At least two unique official-train molecules are required for "
            "global train/validation splitting"
        )

    train_smiles, val_smiles = train_test_split(
        unique_smiles,
        test_size=val_ratio,
        random_state=split_seed,
        shuffle=True,
        stratify=None,
    )
    train_smiles, val_smiles = set(train_smiles), set(val_smiles)
    if train_smiles & val_smiles:
        raise AssertionError("Global canonical-SMILES train/validation overlap")
    return train_smiles, val_smiles


def single_cut_bilateral_regions(first, second):
    """Locate the smallest corresponding A/B replacement on a shared core."""
    second_by_core = defaultdict(list)
    for fragment in second["fragments"]:
        second_by_core[fragment["core"]].append(fragment)

    paired = []
    for first_fragment in first["fragments"]:
        for second_fragment in second_by_core.get(first_fragment["core"], []):
            if first_fragment["sub"] == second_fragment["sub"]:
                continue
            paired.append((
                len(first_fragment["sub_atoms"]) + len(second_fragment["sub_atoms"]),
                first_fragment,
                second_fragment,
            ))
    if not paired:
        return None

    # Equivalent larger cuts can describe the same transformation less
    # locally. Retain only the smallest bilateral changed-side description.
    minimum_size = min(item[0] for item in paired)
    paired = [item for item in paired if item[0] == minimum_size]
    unique = {}
    for _, first_fragment, second_fragment in paired:
        key = (
            tuple(sorted(first_fragment["sub_atoms"])),
            tuple(sorted(second_fragment["sub_atoms"])),
        )
        unique.setdefault(key, (first_fragment, second_fragment))

    first_regions, second_regions = [], []
    for (first_atoms, second_atoms), (first_fragment, second_fragment) in unique.items():
        first_regions.append({
            "atom_indices": list(first_atoms),
            "connection_bond_indices": [int(first_fragment["connection_bond_idx"])],
            "localization_method": "single_cut_mmp",
            "localization_confidence": 1.0,
        })
        second_regions.append({
            "atom_indices": list(second_atoms),
            "connection_bond_indices": [int(second_fragment["connection_bond_idx"])],
            "localization_method": "single_cut_mmp",
            "localization_confidence": 1.0,
        })
    return first_regions, second_regions


def count_region_components(mol, atoms):
    remaining = set(atoms)
    components = 0
    while remaining:
        components += 1
        stack = [remaining.pop()]
        while stack:
            atom = mol.GetAtomWithIdx(stack.pop())
            for neighbor in atom.GetNeighbors():
                idx = neighbor.GetIdx()
                if idx in remaining:
                    remaining.remove(idx)
                    stack.append(idx)
    return components


def mcs_region(current, reference, args):
    """Conservative fallback: changed atoms plus the mapped interface atoms."""
    mol, ref_mol = current["mol"], reference["mol"]
    result = rdFMCS.FindMCS(
        [mol, ref_mol],
        timeout=args.mcs_timeout_seconds,
        atomCompare=rdFMCS.AtomCompare.CompareElements,
        bondCompare=rdFMCS.BondCompare.CompareOrder,
        ringMatchesRingOnly=True,
        completeRingsOnly=True,
    )
    if result.canceled or result.numAtoms < args.mcs_min_atoms:
        return None
    query = Chem.MolFromSmarts(result.smartsString)
    if query is None:
        return None
    current_match = mol.GetSubstructMatch(query)
    reference_match = ref_mol.GetSubstructMatch(query)
    if not current_match or not reference_match:
        return None

    mcs_fraction = result.numAtoms / max(1, min(mol.GetNumAtoms(), ref_mol.GetNumAtoms()))
    if mcs_fraction < args.mcs_min_core_fraction:
        return None

    current_core = set(current_match)
    reference_core = set(reference_match)
    region = set(range(mol.GetNumAtoms())) - current_core

    # Add interface atoms on the current side. This also creates a meaningful
    # target when the structural change is a deletion relative to the reference.
    query_to_current = {query_idx: atom_idx for query_idx, atom_idx in enumerate(current_match)}
    reference_to_query = {atom_idx: query_idx for query_idx, atom_idx in enumerate(reference_match)}
    for atom_idx in list(region):
        for neighbor in mol.GetAtomWithIdx(atom_idx).GetNeighbors():
            if neighbor.GetIdx() in current_core:
                region.add(neighbor.GetIdx())
    for ref_atom_idx in reference_core:
        if any(neighbor.GetIdx() not in reference_core
               for neighbor in ref_mol.GetAtomWithIdx(ref_atom_idx).GetNeighbors()):
            region.add(query_to_current[reference_to_query[ref_atom_idx]])

    if not region or len(region) > args.mcs_max_region_atoms:
        return None
    region_fraction = len(region) / mol.GetNumAtoms()
    if region_fraction > args.mcs_max_region_fraction:
        return None
    if count_region_components(mol, region) > args.mcs_max_components:
        return None

    crossing_bonds = []
    for bond in mol.GetBonds():
        inside_a = bond.GetBeginAtomIdx() in region
        inside_b = bond.GetEndAtomIdx() in region
        if inside_a != inside_b:
            crossing_bonds.append(bond.GetIdx())
    confidence = max(0.4, min(0.8, mcs_fraction * (1.0 - 0.5 * region_fraction)))
    return {
        "atom_indices": sorted(region),
        "connection_bond_indices": sorted(crossing_bonds),
        "localization_method": "mcs_fallback",
        "localization_confidence": confidence,
        "mcs_atoms": int(result.numAtoms),
        "mcs_core_fraction": mcs_fraction,
        "region_fraction": region_fraction,
    }


def bilateral_regions(
    first, second, args, stats, mcs_attempt_counts, count_second_attempt
):
    """Return corresponding regions only when both pair members localize."""
    if "single_cut" in args.localization_methods:
        localized = single_cut_bilateral_regions(first, second)
        if localized is not None:
            return localized

    if "mcs" in args.localization_methods:
        if args.max_mcs_attempts_per_molecule > 0 and (
            mcs_attempt_counts[first["row_idx"]] >= args.max_mcs_attempts_per_molecule
            or (
                count_second_attempt
                and mcs_attempt_counts[second["row_idx"]]
                >= args.max_mcs_attempts_per_molecule
            )
        ):
            stats["bilateral_mcs_pairs_skipped_by_attempt_cap"] += 1
            return None
        mcs_attempt_counts[first["row_idx"]] += 1
        if count_second_attempt:
            mcs_attempt_counts[second["row_idx"]] += 1
        stats["bilateral_mcs_pairs_attempted"] += 1
        first_region = mcs_region(first, second, args)
        second_region = mcs_region(second, first, args)
        if first_region is not None and second_region is not None:
            return [first_region], [second_region]
    return None


def collect_pair_effects(anchors, references, args, symmetric):
    """Derive labels from strict pairs, then weak pairs for uncovered rows."""
    effects = defaultdict(lambda: defaultdict(list))
    stats = defaultdict(int)
    localized_counts = defaultdict(int)
    mcs_attempt_counts = defaultdict(int)

    candidates = []
    for first in anchors:
        for second in references:
            if first is second or first["smiles"] == second["smiles"]:
                continue
            if symmetric and first["row_idx"] >= second["row_idx"]:
                continue
            delta = first["y"] - second["y"]
            if abs(delta) <= args.min_abs_delta_y:
                continue
            similar, similarity_info = official_similarity(
                first, second, args.fallback_similarity_threshold
            )
            if not similar:
                continue
            pair_tier = (
                "strict" if similarity_info["max_similarity"]
                >= args.similarity_threshold else "weak_fallback"
            )
            tier_order = 0 if pair_tier == "strict" else 1
            candidates.append((
                tier_order, similarity_info["max_similarity"], abs(delta),
                first, second, delta, similarity_info, pair_tier,
            ))
    candidates.sort(key=lambda item: (item[0], -item[1], -item[2]))
    stats["qualifying_candidate_pairs"] = len(candidates)
    stats["strict_candidate_pairs"] = sum(item[0] == 0 for item in candidates)
    stats["weak_fallback_candidate_pairs"] = sum(item[0] == 1 for item in candidates)

    def at_cap(row):
        return (
            args.max_references_per_molecule > 0
            and localized_counts[row["row_idx"]] >= args.max_references_per_molecule
        )

    def add_side(
        current, reference, signed_delta, similarity_info, regions,
        pair_tier, pair_weight,
    ):
        localized_counts[current["row_idx"]] += 1
        for region in regions:
            atom_key = tuple(sorted(int(atom) for atom in region["atom_indices"]))
            effects[current["row_idx"]][atom_key].append({
                "signed_delta_y": signed_delta,
                "reference_smiles": reference["smiles"],
                "reference_row_idx": reference["row_idx"],
                "reference_split": reference["split"],
                "connection_bond_indices": region["connection_bond_indices"],
                "localization_method": region["localization_method"],
                "localization_confidence": (
                    region["localization_confidence"] * pair_weight
                ),
                "mcs_core_fraction": region.get("mcs_core_fraction"),
                "pair_tier": pair_tier,
                "pair_supervision_weight": pair_weight,
                **similarity_info,
            })

    for (
        tier_order, _, _, first, second, delta, similarity_info, pair_tier
    ) in candidates:
        if tier_order == 1:
            first_covered = bool(effects.get(first["row_idx"]))
            second_covered = bool(effects.get(second["row_idx"]))
            if (not symmetric and first_covered) or (
                symmetric and first_covered and second_covered
            ):
                stats["weak_pairs_skipped_for_covered_molecules"] += 1
                continue
        if at_cap(first) or (symmetric and at_cap(second)):
            stats["candidate_pairs_skipped_by_reference_cap"] += 1
            continue
        localized = bilateral_regions(
            first, second, args, stats, mcs_attempt_counts,
            count_second_attempt=symmetric,
        )
        if localized is None:
            stats["candidate_pairs_without_bilateral_regions"] += 1
            continue
        first_regions, second_regions = localized
        pair_weight = (
            1.0 if pair_tier == "strict" else args.fallback_pair_weight
        )
        add_side(
            first, second, delta, similarity_info, first_regions,
            pair_tier, pair_weight,
        )
        if symmetric:
            add_side(
                second, first, -delta, similarity_info, second_regions,
                pair_tier, pair_weight,
            )
        stats["accepted_bilateral_pairs"] += 1
        stats[f"accepted_{pair_tier}_pairs"] += 1
        methods = {
            region["localization_method"]
            for region in first_regions + second_regions
        }
        for method in methods:
            stats[f"accepted_pairs_{method}"] += 1

    stats["derived_positive_molecules"] = sum(bool(value) for value in effects.values())
    for molecule_effects in effects.values():
        tiers = {
            item["pair_tier"]
            for observations in molecule_effects.values()
            for item in observations
        }
        if "strict" in tiers:
            stats["derived_positive_molecules_with_strict_pair"] += 1
        elif "weak_fallback" in tiers:
            stats["derived_positive_molecules_weak_only"] += 1
    return effects, dict(stats)


def output_row(row, observations_by_atoms, max_regions):
    regions = []
    for atoms, observations in observations_by_atoms.items():
        signed_values = [item["signed_delta_y"] for item in observations]
        mean_signed = sum(signed_values) / len(signed_values)
        # Keep an accepted pair-derived region even if several observations
        # cancel exactly. Use the strongest observation to break that rare tie.
        direction_source = (
            mean_signed if mean_signed != 0
            else max(signed_values, key=abs)
        )
        direction = 1 if direction_source > 0 else -1
        agreement = sum((value > 0) == (direction > 0) for value in signed_values) / len(signed_values)
        supervision_weight = sum(
            item["pair_supervision_weight"] for item in observations
        ) / len(observations)
        regions.append({
            "atom_indices": list(atoms),
            "connection_bond_indices": sorted({
                bond for item in observations for bond in item["connection_bond_indices"]
            }),
            "signed_delta_y": mean_signed,
            "direction": direction,
            "direction_label": int(direction > 0),
            "magnitude": sum(abs(value) for value in signed_values) / len(signed_values),
            "direction_agreement": agreement,
            "localization_methods": sorted({item["localization_method"] for item in observations}),
            "localization_confidence": sum(item["localization_confidence"] for item in observations) / len(observations),
            "supervision_weight": supervision_weight,
            "pair_tiers": sorted({item["pair_tier"] for item in observations}),
            "count": len(observations),
            "references": [{
                "smiles": item["reference_smiles"],
                "row_idx": item["reference_row_idx"],
                "split": item["reference_split"],
                "signed_delta_y": item["signed_delta_y"],
                "similarity_methods": item["similarity_methods"],
                "max_similarity": item["max_similarity"],
                "localization_method": item["localization_method"],
                "localization_confidence": item["localization_confidence"],
                "pair_tier": item["pair_tier"],
                "pair_supervision_weight": item["pair_supervision_weight"],
            } for item in observations],
        })
    regions.sort(
        key=lambda item: (
            item["magnitude"]
            * item["direction_agreement"]
            * item["localization_confidence"]
        ),
        reverse=True,
    )
    if max_regions > 0:
        regions = regions[:max_regions]
    derived_cliff_label = int(bool(regions))
    return {
        "dataset": row["dataset"],
        "row_idx": row["row_idx"],
        "smiles": row["smiles"],
        "canonical_smiles": row["canonical_smiles"],
        "y": row["y"],
        "split": row["split"],
        # Kept for downstream schema compatibility, but both labels are
        # derived exclusively from accepted bilateral pairs.
        "cliff_mol": derived_cliff_label,
        "cliff_existence_label": derived_cliff_label,
        "regions": regions,
        "num_regions": len(regions),
        "has_region": derived_cliff_label,
        "max_region_magnitude": max((item["magnitude"] for item in regions), default=0.0),
    }


def write_jsonl(path, rows, effects, max_regions):
    path.parent.mkdir(parents=True, exist_ok=True)
    counts = defaultdict(int)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            item = output_row(row, effects.get(row["row_idx"], {}), max_regions)
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")
            counts["molecules"] += 1
            counts["derived_cliff_molecules"] += item["cliff_mol"]
            counts["molecules_with_region"] += item["has_region"]
            counts["regions"] += item["num_regions"]
            if item["cliff_mol"] and not item["has_region"]:
                counts["derived_cliffs_without_region"] += 1
    return dict(counts)


def parse_args():
    parser = argparse.ArgumentParser(description="Build leakage-safe pair-derived MoleculeACE region supervision")
    parser.add_argument("--input_dir", required=True, help="Directory containing the 30 MoleculeACE CSV files")
    parser.add_argument("--output", required=True, help="TRAIN-only JSONL used by the model")
    parser.add_argument("--val_output", default=None,
                        help="Validation JSONL; default derived from --output")
    parser.add_argument("--val_ratio", type=float, default=0.1,
                        help="Fraction of global unique canonical SMILES reserved for validation")
    parser.add_argument("--val_split_seed", type=int, default=0,
                        help="Fixed seed for the reproducible train/validation split")
    parser.add_argument("--smiles_col", default="smiles")
    parser.add_argument("--y_col", default="y [pEC50/pKi]")
    parser.add_argument("--split_col", default="split")
    parser.add_argument("--similarity_threshold", type=float, default=0.90,
                        help="Strict pair similarity threshold")
    parser.add_argument("--fallback_similarity_threshold", type=float, default=0.85,
                        help="Weak fallback threshold used only for uncovered molecules")
    parser.add_argument("--fallback_pair_weight", type=float, default=0.5,
                        help="Confidence/supervision weight recorded for weak fallback pairs")
    parser.add_argument("--min_abs_delta_y", type=float, default=1.0,
                        help="Strict lower bound; 1.0 corresponds to MoleculeACE potency_fold > 10")
    parser.add_argument("--fp_radius", type=int, default=2)
    parser.add_argument("--fp_bits", type=int, default=1024)
    parser.add_argument("--min_core_atoms", type=int, default=3)
    parser.add_argument("--max_sub_heavy_atoms", type=int, default=30)
    parser.add_argument("--max_radius", type=int, default=3)
    parser.add_argument("--max_references_per_molecule", type=int, default=20)
    parser.add_argument("--max_regions_per_mol", type=int, default=16)
    parser.add_argument("--localization_methods", default="single_cut,mcs",
                        help="Comma-separated ordered methods: single_cut,mcs")
    parser.add_argument("--mcs_timeout_seconds", type=int, default=1)
    parser.add_argument("--max_mcs_attempts_per_molecule", type=int, default=3,
                        help="Maximum bilateral MCS attempts per molecule")
    parser.add_argument("--mcs_min_atoms", type=int, default=3)
    parser.add_argument("--mcs_min_core_fraction", type=float, default=0.60)
    parser.add_argument("--mcs_max_region_atoms", type=int, default=20)
    parser.add_argument("--mcs_max_region_fraction", type=float, default=0.50)
    parser.add_argument("--mcs_max_components", type=int, default=2)
    parser.add_argument("--progress_every_dataset", type=int, default=1)
    return parser.parse_args()


def main():
    args = parse_args()
    if not 0.0 <= args.fallback_similarity_threshold <= args.similarity_threshold <= 1.0:
        raise ValueError(
            "Require 0 <= fallback_similarity_threshold <= "
            "similarity_threshold <= 1"
        )
    if not 0.0 < args.fallback_pair_weight <= 1.0:
        raise ValueError("fallback_pair_weight must be in (0, 1]")
    args.localization_methods = [item.strip() for item in args.localization_methods.split(",") if item.strip()]
    unknown_methods = set(args.localization_methods) - {"single_cut", "mcs"}
    if unknown_methods:
        raise ValueError(f"Unknown localization methods: {sorted(unknown_methods)}")
    input_dir = Path(args.input_dir)
    csv_files = sorted(input_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No CSV files found in {input_dir}")

    output = Path(args.output)
    val_output = (Path(args.val_output) if args.val_output else
                  output.with_name(output.stem + "_val.jsonl"))
    train_items, val_items, per_dataset = [], [], {}

    # Read every target first so that test molecules can be excluded globally.
    # A canonical SMILES appearing in the official test split of any target is
    # forbidden from train/validation/reference use in every target.
    datasets = []
    global_test_smiles = set()
    for csv_path in csv_files:
        rows, invalid = read_dataset(csv_path, args)
        datasets.append((csv_path, rows, invalid))
        global_test_smiles.update(
            row["canonical_smiles"] for row in rows if row["split"] == "test"
        )

    # Split unique canonical molecules globally rather than splitting each
    # target independently. Rows sharing a molecule across targets therefore
    # cannot appear in opposite train/validation subsets.
    global_official_train_smiles = {
        row["canonical_smiles"]
        for _, rows, _ in datasets
        for row in rows
        if row["split"] == "train"
        and row["canonical_smiles"] not in global_test_smiles
    }
    global_train_smiles, global_val_smiles = split_global_canonical_smiles(
        global_official_train_smiles, args.val_ratio, args.val_split_seed
    )

    for dataset_index, (csv_path, rows, invalid) in enumerate(datasets, 1):
        input_valid_rows = len(rows)
        removed_test_rows = sum(row["split"] == "test" for row in rows)

        # Remove both this target's official test rows and train rows whose
        # canonical molecule occurs in any target's official test partition.
        candidate_train = [row for row in rows if row["split"] == "train"]
        official_train = [
            row for row in candidate_train
            if row["canonical_smiles"] not in global_test_smiles
        ]
        removed_cross_target_test_matches = len(candidate_train) - len(official_train)
        if len(candidate_train) + removed_test_rows != input_valid_rows:
            raise AssertionError(f"Unexpected split value survived parsing in {csv_path}")
        if any(row["split"] == "test" for row in official_train):
            raise AssertionError(f"Official test row survived filtering in {csv_path}")
        if any(row["canonical_smiles"] in global_test_smiles for row in official_train):
            raise AssertionError(f"Global test molecule survived filtering in {csv_path}")

        fragment_rows(official_train, args)
        train = [
            row for row in official_train
            if row["canonical_smiles"] in global_train_smiles
        ]
        val = [
            row for row in official_train
            if row["canonical_smiles"] in global_val_smiles
        ]
        if len(train) + len(val) != len(official_train):
            raise AssertionError(
                f"Global split did not assign every official-train row in {csv_path}"
            )
        if not train or not val:
            raise ValueError(
                f"Global molecule split produced an empty subset for {csv_path.stem}: "
                f"train={len(train)}, val={len(val)}"
            )

        # Split before localization: neither train labels nor their aggregates
        # can observe validation molecules or validation activities.
        train_effects, train_stats = collect_pair_effects(
            train, train, args, symmetric=True
        )
        # Validation anchors search final-train references. Both molecular
        # sides must localize, but only validation effects are written, so
        # validation activities never alter final-train labels.
        val_effects, val_stats = collect_pair_effects(
            val, train, args, symmetric=False
        )
        train_items.extend((row, train_effects.get(row["row_idx"], {})) for row in train)
        val_items.extend((dict(row, split="val"), val_effects.get(row["row_idx"], {})) for row in val)
        per_dataset[csv_path.stem] = {
            "input_valid_rows": input_valid_rows, "invalid_rows": invalid,
            "removed_test_rows_before_processing": removed_test_rows,
            "removed_train_rows_matching_global_test": removed_cross_target_test_matches,
            "official_train_rows": len(official_train),
            "train_rows": len(train), "val_rows": len(val),
            "actual_val_ratio": len(val) / len(official_train),
            "train_region_search": train_stats,
            "val_region_search": val_stats,
        }
        if args.progress_every_dataset and dataset_index % args.progress_every_dataset == 0:
            print(f"Processed {dataset_index}/{len(csv_files)}: {csv_path.stem}; "
                  f"subtrain={len(train):,}, val={len(val):,}, "
                  f"removed_test={removed_test_rows:,}, "
                  f"removed_global_test_matches={removed_cross_target_test_matches:,}",
                  flush=True)

    # row_idx is only unique inside a dataset, so write directly from paired
    # (row, effects) tuples rather than combining effect dictionaries.
    def write_items(path, items):
        path.parent.mkdir(parents=True, exist_ok=True)
        counts = defaultdict(int)
        with path.open("w", encoding="utf-8") as handle:
            for row, effect in items:
                item = output_row(row, effect, args.max_regions_per_mol)
                handle.write(json.dumps(item, ensure_ascii=False) + "\n")
                counts["molecules"] += 1
                counts["derived_cliff_molecules"] += item["cliff_mol"]
                counts["molecules_with_region"] += item["has_region"]
                counts["regions"] += item["num_regions"]
                counts["derived_cliffs_without_region"] += int(item["cliff_mol"] == 1 and not item["has_region"])
        return dict(counts)

    written_train_smiles = {
        row["canonical_smiles"] for row, _ in train_items
    }
    written_val_smiles = {
        row["canonical_smiles"] for row, _ in val_items
    }
    cross_target_train_val_overlap = written_train_smiles & written_val_smiles
    if cross_target_train_val_overlap:
        raise AssertionError(
            "Canonical molecules occur in both generated train and validation "
            f"outputs: {len(cross_target_train_val_overlap)}"
        )

    train_counts = write_items(output, train_items)
    val_counts = write_items(val_output, val_items)
    summary = {
        "input_dir": str(input_dir), "datasets": len(csv_files),
        "global_unique_test_canonical_smiles": len(global_test_smiles),
        "train_output": str(output), "val_output": str(val_output),
        "validation_split": {
            "ratio": args.val_ratio,
            "seed": args.val_split_seed,
            "unit": "global unique canonical SMILES across all targets",
            "global_unique_train_smiles": len(global_train_smiles),
            "global_unique_validation_smiles": len(global_val_smiles),
            "cross_target_train_validation_overlap": 0,
            "stratification": "none; official cliff_mol is not read or used",
        },
        "pair_definition": {
            "strict_similarity": f"any of Morgan/scaffold/SMILES-Levenshtein >= {args.similarity_threshold}",
            "fallback_similarity": (
                f"same metrics >= {args.fallback_similarity_threshold}, used only for uncovered molecules"
            ),
            "fallback_pair_weight": args.fallback_pair_weight,
            "potency": f"abs(delta_y) > {args.min_abs_delta_y}",
            "max_mcs_attempts_per_molecule": args.max_mcs_attempts_per_molecule,
        },
        "leakage_policy": (
            "collect canonical SMILES from every target's official test split; remove all official "
            "test rows and all train rows matching any global test molecule before fragmentation "
            "and splitting; globally assign each remaining canonical molecule to train or validation "
            "before per-target pair discovery, preventing cross-target train/validation molecule "
            "overlap; train pairs are "
            "symmetric within subtrain; validation anchors use subtrain references with bilateral "
            "localization but cannot modify train labels; test molecules are never processed or generated"
        ),
        "label_policy": (
            "ignore input cliff_mol; process strict pairs first; use weak fallback pairs only for "
            "molecules not already fully covered; require bilateral regions; record reduced "
            "confidence and supervision weight for weak pairs"
        ),
        "region_policy": f"bilateral {args.localization_methods}",
        "train": train_counts, "validation": val_counts,
        "per_dataset": per_dataset,
    }
    summary_path = output.with_name(output.stem + "_summary.json")
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
